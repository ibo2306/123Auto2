const CarsList = [
  { label: "Audi", modeltyp: "A3", price: 10000, image: "" },
  { label: "Audi", modeltyp: "A4", price: 20000 },
  { label: "BMW" },
  { label: "Mercedes " },
  { label: "Skoda" },
  { label: "Volkswagen" },
  { label: "Toyota" },
  { label: "Porsche" },
  { label: "Nissan" },
];

export default CarsList;
