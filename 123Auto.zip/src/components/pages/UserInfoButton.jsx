import React from 'react'

export default function UserInfoButton() {
  return (
    <div>
      <button className='button'>erstellen</button>
    </div>
  )
}
